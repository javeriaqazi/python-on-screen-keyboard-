import tkinter as tk

def on_key_press(key):
    current_text = entry_var.get()
    if key == 'Space':
        entry_var.set(current_text + ' ')
    elif key == 'BackSpace':
        entry_var.set(current_text[:-1])
    else:
        entry_var.set(current_text + key)

root = tk.Tk()
root.title("On-Screen Keyboard")

entry_var = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_var, font=('Arial', 16))
entry.grid(row=0, column=0, columnspan=10, padx=10, pady=10)

keys = [
    '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
    'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P',
    'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L',
    'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.',
    'Space', 'BackSpace'
]

row_val = 1
col_val = 0

for key in keys:
    tk.Button(root, text=key, command=lambda k=key: on_key_press(k)).grid(row=row_val, column=col_val, ipadx=10, ipady=10)
    col_val += 1
    if col_val > 9:
        col_val = 0
        row_val += 1

root.mainloop()
